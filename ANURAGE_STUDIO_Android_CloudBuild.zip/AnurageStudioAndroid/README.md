# ANURAGE STUDIO — Android app project (prototype 0.1.0)

This is a native Android Studio project that wraps the mobile prototype UI in an Android WebView shell. It can be built into an APK using Android Studio.

## What is included
- Android launcher app named ANURAGE STUDIO.
- Mobile UI with Shorts Creator and Video Creator tabs.
- Android video-file picker integration.
- Caption on/off and script selector controls.
- Facecam layout mock previews and framing sliders.
- Demo candidate clip cards.

## What is not implemented yet
This is a UI prototype, not the finished video editor:
- No AI highlight detection or actual clip rendering.
- No Whisper/Hinglish transcription engine connected.
- No actual facecam detection/tracking or draggable crop/keyframe editor.
- No video enhancement or export pipeline.
- The sample clip cards are demonstrative only.

## Build an APK
1. Install Android Studio on a PC/Mac.
2. Extract this project folder.
3. In Android Studio, choose **Open** and select the `AnurageStudioAndroid` folder.
4. Let Gradle sync. Android Studio may download Gradle and Android SDK components.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer that APK to your Android phone and install it. You may need to allow installation from that file manager.

## Build requirements
- Android Studio with Android SDK Platform 35.
- JDK 17 (bundled JBR in Android Studio is suitable).
- Internet during initial Gradle/SDK setup.

This environment did not have Android SDK/Gradle installed, so an APK could not be compiled here. The source project is prepared for Android Studio.


## Build without installing Android Studio (GitHub cloud build)
A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`.

1. Create a new GitHub repository.
2. Upload the contents of this project folder to the repository (including the `.github` folder).
3. Open the repository's **Actions** tab and run **Build ANURAGE STUDIO APK** (or push to `main`).
4. When the run completes, open it and download the artifact named `ANURAGE-STUDIO-debug-apk`.
5. Extract the downloaded artifact on your phone and tap `app-debug.apk` to install.

This uses GitHub's hosted build machine; you do not need Android Studio on your own PC. You do need a GitHub account and must upload the project source. The resulting APK remains a prototype shell; it does not magically add the unfinished AI/video-processing features.
